here I have write my js code inside js/scipts.js
Js file  have a function showCalender() which will work on loading the page.
